//author: Haonan Di
//author andrew id: hdi
package hw1;

public class GameRound {

	String puzzleWord;
	String clueWord;
	boolean isRoundComplete;
	public String getPuzzleWord() {
		return puzzleWord;
	}
	public void setPuzzleWord(String puzzleWord) {
		this.puzzleWord = puzzleWord;
	}
	public String getClueWord() {
		return clueWord;
	}
	public void setClueWord(String clueWord) {
		this.clueWord = clueWord;
	}
	public boolean getIsRoundComplete() {
		return isRoundComplete;
	}
	public void setIsRoundComplete(boolean isRoundComplete) {
		this.isRoundComplete = isRoundComplete;
	}
	
}
