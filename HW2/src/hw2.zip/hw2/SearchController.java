package hw2;

public class SearchController extends WordNerdController {
	
	//this is a placeholder class. Will be completed in HW3

	@Override
	void startController() {
		//to be implemented in HW3
	}

	@Override
	void setupBindings() {
		//to be implemented in HW3
	}

}
