package hw2;

public abstract class WordNerdController {
	
	WordNerdModel wordNerdModel = new WordNerdModel();

	abstract void startController();

	abstract void setupBindings();
	

}
