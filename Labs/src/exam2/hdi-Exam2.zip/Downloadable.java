//name: Haonan Di
//andrew id: hdi
package exam2;

public interface Downloadable {

	final static int INTERNET_SPEED = 40;
	
	abstract int download();
}
