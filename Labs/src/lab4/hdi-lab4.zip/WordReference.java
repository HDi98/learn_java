//name: Haonan Di
//andrew id: hdi
package lab4;

public abstract class WordReference {

	String[][] wordData;
	abstract String[] lookup(String word);
}
