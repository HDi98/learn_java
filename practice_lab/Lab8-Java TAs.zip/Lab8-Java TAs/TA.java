package lab8;

public class TA implements Runnable, Comparable<TA>{

	static int totalHelpTime;  //total time spent so far across all TA's
	static int taCount; //number of TAs
	static final int MAX_HELP_TIME = 120; //max total time a TA can spend across all students

	int studentsHelped; //number of students helped by a TA so far
	int helpTime;  //total time spent by a TA so far 

	int taID; //TA's unique id

	TA() {
		taID = ++taCount;
	}

	@Override
	public void run() {
		//write your code here
	}

	@Override
	public int compareTo(TA o) {
		//write your code here
		return 0;
	}


	//do not change this method
	String spacer(int taID) {
		StringBuilder spaces = new StringBuilder();
		for (int i = 1; i < taID; i++) {
			spaces.append("\t\t");
		}
		return spaces.toString();
	}
}
